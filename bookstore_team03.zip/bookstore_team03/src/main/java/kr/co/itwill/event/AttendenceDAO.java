package kr.co.itwill.event;

public class AttendenceDAO {

}//class end
